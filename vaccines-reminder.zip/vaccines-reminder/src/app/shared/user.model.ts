export class User {
  petiant_name: string;
  age: number;
  fathers_name: string;
  mothers_name: string;
  date_of_birth: Date;
  date: Date;
}
