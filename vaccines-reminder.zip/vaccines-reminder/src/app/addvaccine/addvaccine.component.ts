import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addvaccine',
  templateUrl: './addvaccine.component.html',
  styleUrls: ['./addvaccine.component.css']
})
export class AddvaccineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
